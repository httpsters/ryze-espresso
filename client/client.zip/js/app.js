var riseApp = angular.module("riseApp", [
	'riseApp.services',
    'riseApp.controllers',
    'firebase'
]);
angular.module('riseApp.services', []);
angular.module('riseApp.controllers', []);
// check out the angular seed template for more help with templates, 
// routes, directives and stuff
// https://github.com/angular/angular-seed/blob/master/app/js/app.js 

